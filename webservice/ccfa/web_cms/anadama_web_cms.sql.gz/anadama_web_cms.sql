-- MySQL dump 10.13  Distrib 5.1.73, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: anadama_web_cms
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_5f412f9a` (`group_id`),
  KEY `auth_group_permissions_83d7f98b` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_37ef4eb4` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add permission',1,'add_permission'),(2,'Can change permission',1,'change_permission'),(3,'Can delete permission',1,'delete_permission'),(4,'Can add group',2,'add_group'),(5,'Can change group',2,'change_group'),(6,'Can delete group',2,'delete_group'),(7,'Can add user',3,'add_user'),(8,'Can change user',3,'change_user'),(9,'Can delete user',3,'delete_user'),(10,'Can add content type',4,'add_contenttype'),(11,'Can change content type',4,'change_contenttype'),(12,'Can delete content type',4,'delete_contenttype'),(13,'Can add redirect',5,'add_redirect'),(14,'Can change redirect',5,'change_redirect'),(15,'Can delete redirect',5,'delete_redirect'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(19,'Can add site',7,'add_site'),(20,'Can change site',7,'change_site'),(21,'Can delete site',7,'delete_site'),(22,'Can add Setting',8,'add_setting'),(23,'Can change Setting',8,'change_setting'),(24,'Can delete Setting',8,'delete_setting'),(25,'Can add Site permission',9,'add_sitepermission'),(26,'Can change Site permission',9,'change_sitepermission'),(27,'Can delete Site permission',9,'delete_sitepermission'),(28,'Can add Comment',10,'add_threadedcomment'),(29,'Can change Comment',10,'change_threadedcomment'),(30,'Can delete Comment',10,'delete_threadedcomment'),(31,'Can add Keyword',11,'add_keyword'),(32,'Can change Keyword',11,'change_keyword'),(33,'Can delete Keyword',11,'delete_keyword'),(34,'Can add assigned keyword',12,'add_assignedkeyword'),(35,'Can change assigned keyword',12,'change_assignedkeyword'),(36,'Can delete assigned keyword',12,'delete_assignedkeyword'),(37,'Can add Rating',13,'add_rating'),(38,'Can change Rating',13,'change_rating'),(39,'Can delete Rating',13,'delete_rating'),(40,'Can add Form',14,'add_form'),(41,'Can change Form',14,'change_form'),(42,'Can delete Form',14,'delete_form'),(43,'Can add Field',15,'add_field'),(44,'Can change Field',15,'change_field'),(45,'Can delete Field',15,'delete_field'),(46,'Can add Form entry',16,'add_formentry'),(47,'Can change Form entry',16,'change_formentry'),(48,'Can delete Form entry',16,'delete_formentry'),(49,'Can add Form field entry',17,'add_fieldentry'),(50,'Can change Form field entry',17,'change_fieldentry'),(51,'Can delete Form field entry',17,'delete_fieldentry'),(52,'Can add Page',18,'add_page'),(53,'Can change Page',18,'change_page'),(54,'Can delete Page',18,'delete_page'),(55,'Can add Rich text page',19,'add_richtextpage'),(56,'Can change Rich text page',19,'change_richtextpage'),(57,'Can delete Rich text page',19,'delete_richtextpage'),(58,'Can add Link',20,'add_link'),(59,'Can change Link',20,'change_link'),(60,'Can delete Link',20,'delete_link'),(61,'Can add log entry',21,'add_logentry'),(62,'Can change log entry',21,'change_logentry'),(63,'Can delete log entry',21,'delete_logentry'),(64,'Can add comment',22,'add_comment'),(65,'Can change comment',22,'change_comment'),(66,'Can delete comment',22,'delete_comment'),(67,'Can moderate comments',22,'can_moderate'),(68,'Can add comment flag',23,'add_commentflag'),(69,'Can change comment flag',23,'change_commentflag'),(70,'Can delete comment flag',23,'delete_commentflag'),(71,'Can add Category',24,'add_category'),(72,'Can change Category',24,'change_category'),(73,'Can delete Category',24,'delete_category'),(74,'Can add Question',25,'add_question'),(75,'Can change Question',25,'change_question'),(76,'Can delete Question',25,'delete_question'),(77,'Can add Response',26,'add_response'),(78,'Can change Response',26,'change_response'),(79,'Can delete Response',26,'delete_response');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$12000$ZzV31OLDfuDk$HwwCzdjzY8+wOVQTBPxohZLHDo7asuheZKbOzogX0bM=','2016-02-04 15:00:41',1,'rschwager','Randall','Schwager','schwager@hsph.harvard.edu',1,1,'2014-05-24 17:27:00'),(2,'!YwWMnIN6nXPiVY60YSaWESshc20oVZSkXIRUX6Dm','2015-01-22 15:08:14',0,'kbayer','Keith','Bayer','',1,1,'2014-05-30 19:13:23'),(5,'pbkdf2_sha256$12000$iXApHOtK7ftA$s9WYTlpKnHyQMFGNODvwR5EOwn6cVyZorslllFQg8dc=','2014-07-10 06:12:25',0,'mtong09','Maomeng','Tong','mtong09@gmail.com',1,1,'2014-07-08 22:03:32'),(6,'!68IaAhwiMhPQoWHUJe1MakiykmKlUPGc2tncZ0GQ','2016-01-15 21:52:17',0,'chuttenhower','Curtis','Huttenhower','',1,1,'2014-07-10 10:45:55'),(7,'!YOGxjprr0TvpoohUcncpgc3O5MmvTLLdGcEkIUvj','2015-01-07 19:27:58',0,'yuanhaozhang','Yuanhao','Zhang','',1,1,'2014-08-07 18:15:21'),(8,'pbkdf2_sha256$12000$uLbrhiMPamcM$Tzg4XrtEF4HrNjYO+HsbRS5yvNO7ybZg2aqypt9Y8Zo=','2014-11-09 04:16:25',0,'vlam','Vy','Lam','vylam03@gmail.com',1,1,'2014-09-03 17:13:48'),(9,'pbkdf2_sha256$12000$O9kMMcBreKuq$XN0JWG1b4OPfRzLcewdp9rMr64hlfTay8vi+nqImhEs=','2014-11-24 17:22:48',0,'nsalzman','Nita','Salzman','nsalzman@mcw.edu',1,1,'2014-09-05 18:15:42'),(10,'pbkdf2_sha256$12000$zID7bgZUrPE9$gICBi9lVZ0AZhk4jYz1ExcSu0yR0KtN/IDuBaLodWuQ=','2014-09-22 18:17:46',0,'moran','Moran','Yassour','moran@broadinstitute.org',1,1,'2014-09-22 18:17:45'),(11,'pbkdf2_sha256$12000$zPCGDV5J7C6G$JhpIe39+kZdDiekGnIdbIOD/UeunDAJtuAYoCfS9Pz8=','2014-11-24 17:36:26',0,'JJacobs','Jonathan','Jacobs','JJacobs@mednet.ucla.edu',1,1,'2014-09-22 18:17:55'),(12,'pbkdf2_sha256$12000$vmGuEaJ6gG5q$8hq60+0gh6SQlNV6FQl3LgovChj48YAbNKs9FWUhWco=','2014-09-22 19:38:54',0,'dcasero','David','Casero','dcasero@ucla.edu',1,1,'2014-09-22 19:38:54'),(13,'pbkdf2_sha256$12000$BFq8bm8cR4hL$NYm6sOpM34agK5Nq3GQ6Q6VbS3EF6tZo5InVUBAHxIQ=','2014-12-12 22:52:28',0,'yulingchang','Yu-Ling','Chang','yulingchang@ucla.edu',1,1,'2014-11-03 18:43:14'),(22,'pbkdf2_sha256$12000$V6V5eoOgOgOr$vOOS5cvLrr1EKpl8t+UMhFHE1DwQ3fZruruL8uuEmyQ=','2015-05-13 22:11:29',0,'morganx','xochitl','morgan','xmorgan@hsph.harvard.edu',1,1,'2015-05-13 22:11:29'),(21,'pbkdf2_sha256$12000$p8o3MCzsFN1O$vHcFbpci7Ri75MdxMOFeYRR7jXicEsy6TdWrhqsdQZw=','2015-05-27 20:24:11',0,'kylebittinger','','','',1,1,'2015-04-24 18:58:45'),(20,'pbkdf2_sha256$12000$WsHC8RGvtI7i$q7+k+3cBh7tLpzumkSYW4VIlhySRVVVsCSnwwz++r6M=','2015-02-04 14:47:26',0,'lewisjd','James','Lewis','lewisjd@upenn.edu',0,1,'2015-02-04 14:47:26'),(19,'pbkdf2_sha256$12000$oPKE84seW64z$1xUKh8Ls4er4zSwpnafl4EC6zrw9LpczQ6ERMmlMFp0=','2015-01-25 22:58:28',0,'UrkoMarigorta_GeorgiaTech','Urko','Marigorta','urko.martinez@biology.gatech.edu',0,1,'2015-01-25 22:58:28'),(23,'pbkdf2_sha256$12000$Iha1NE2kdSP5$9OZiKl6RiZ7hJWOsnEi7jiyxkuq0jZ6L0Si1U4+mL40=','2015-06-02 14:40:20',0,'teaokou1','David','Okou','david.okou@emory.edu',0,1,'2015-06-02 14:35:18');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_6340c63c` (`user_id`),
  KEY `auth_user_groups_5f412f9a` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_6340c63c` (`user_id`),
  KEY `auth_user_user_permissions_83d7f98b` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conf_setting`
--

DROP TABLE IF EXISTS `conf_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conf_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `value` varchar(2000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `conf_setting_99732b5c` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conf_setting`
--

LOCK TABLES `conf_setting` WRITE;
/*!40000 ALTER TABLE `conf_setting` DISABLE KEYS */;
INSERT INTO `conf_setting` VALUES (1,1,'GOOGLE_ANALYTICS_ID',''),(2,1,'ADMIN_MENU_COLLAPSED','False'),(3,1,'SEARCH_PER_PAGE','10'),(4,1,'COMMENTS_NUM_LATEST','5'),(5,1,'ACCOUNTS_APPROVAL_EMAILS','schwager@hsph.harvard.edu,kbayer@hsph.harvard.edu'),(6,1,'RICHTEXT_FILTER_LEVEL','1'),(7,1,'COMMENTS_UNAPPROVED_VISIBLE','True'),(8,1,'SITE_TAGLINE','Your friendly microbiome research support center'),(9,1,'COMMENTS_REMOVED_VISIBLE','True'),(10,1,'BITLY_ACCESS_TOKEN',''),(11,1,'SSL_ENABLED','False'),(12,1,'AKISMET_API_KEY',''),(13,1,'COMMENTS_DEFAULT_APPROVED','False'),(14,1,'COMMENTS_NOTIFICATION_EMAILS',''),(15,1,'COMMENTS_DISQUS_API_PUBLIC_KEY',''),(16,1,'COMMENTS_DISQUS_API_SECRET_KEY',''),(17,1,'COMMENTS_ACCOUNT_REQUIRED','True'),(18,1,'MAX_PAGING_LINKS','10'),(19,1,'TAG_CLOUD_SIZES','4'),(20,1,'COMMENTS_DISQUS_SHORTNAME',''),(21,1,'SSL_FORCE_HOST',''),(22,1,'RATINGS_ACCOUNT_REQUIRED','False');
/*!40000 ALTER TABLE `conf_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `core_sitepermission`
--

DROP TABLE IF EXISTS `core_sitepermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `core_sitepermission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `core_sitepermission_6340c63c` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_sitepermission`
--

LOCK TABLES `core_sitepermission` WRITE;
/*!40000 ALTER TABLE `core_sitepermission` DISABLE KEYS */;
INSERT INTO `core_sitepermission` VALUES (1,2),(2,5),(3,6),(4,7),(5,9),(6,11),(7,10),(8,8),(9,12),(10,13),(11,21),(12,22);
/*!40000 ALTER TABLE `core_sitepermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `core_sitepermission_sites`
--

DROP TABLE IF EXISTS `core_sitepermission_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `core_sitepermission_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sitepermission_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sitepermission_id` (`sitepermission_id`,`site_id`),
  KEY `core_sitepermission_sites_0780734a` (`sitepermission_id`),
  KEY `core_sitepermission_sites_99732b5c` (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_sitepermission_sites`
--

LOCK TABLES `core_sitepermission_sites` WRITE;
/*!40000 ALTER TABLE `core_sitepermission_sites` DISABLE KEYS */;
INSERT INTO `core_sitepermission_sites` VALUES (2,1,1),(3,2,1),(4,3,1),(5,4,1),(6,5,1),(7,6,1),(8,7,1),(9,8,1),(10,9,1),(11,10,1),(12,11,1),(13,12,1);
/*!40000 ALTER TABLE `core_sitepermission_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_6340c63c` (`user_id`),
  KEY `django_admin_log_37ef4eb4` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2014-05-24 21:28:12',1,19,'1','Tools',1,''),(2,'2014-05-24 21:29:49',1,20,'2','Tools / Metadata Generator',1,''),(3,'2014-05-24 21:30:23',1,20,'3','Tools / Sample-level Metadata Editor',1,''),(4,'2014-05-24 21:30:42',1,20,'4','Tools / Metatadata Validator',1,''),(5,'2014-05-24 21:31:25',1,19,'1','Tools',2,'Changed content and keywords.'),(6,'2014-05-28 17:33:04',1,20,'5','Tools / Support Tickets',1,''),(7,'2014-05-28 17:33:23',1,20,'6','Tools / Files',1,''),(8,'2014-05-28 17:54:37',1,24,'1','Site improvements',1,''),(9,'2014-05-28 17:54:56',1,24,'2','Workflow suggestions',1,''),(10,'2014-05-28 17:55:02',1,24,'3','Special analyses',1,''),(11,'2014-05-30 13:01:57',1,18,'5','Tools / Support Tickets',3,''),(12,'2014-05-30 13:02:27',1,19,'1','Tools',2,'Changed content and keywords.'),(13,'2014-05-30 13:03:02',1,20,'7','Support Tickets',1,''),(14,'2014-05-30 14:48:54',1,19,'8','Documents',1,''),(15,'2014-07-07 19:03:12',1,3,'3','trundleduck',3,''),(16,'2014-07-07 19:47:17',1,3,'4','trundlebunny',3,''),(17,'2014-07-09 12:23:34',1,3,'5','mtong09',2,'Changed is_staff.'),(18,'2014-09-22 18:38:15',1,3,'9','nsalzman',2,'Changed is_staff.'),(19,'2014-09-22 18:38:25',1,3,'11','JJacobs',2,'Changed is_staff.'),(20,'2014-09-22 18:38:31',1,3,'10','moran',2,'Changed is_staff.'),(21,'2014-09-22 18:38:43',1,3,'8','vlam',2,'Changed is_staff.'),(22,'2014-11-03 18:44:51',1,3,'12','dcasero',2,'Changed is_staff.'),(23,'2014-11-03 18:44:57',1,3,'13','yulingchang',2,'Changed is_staff.'),(24,'2015-01-23 18:02:22',1,3,'18','test',3,''),(25,'2015-01-23 18:02:22',1,3,'17','qiupeng',3,''),(26,'2015-01-23 18:02:22',1,3,'16','tmorris',3,''),(27,'2015-01-23 18:02:22',1,3,'15','kmondal',3,''),(28,'2015-01-23 18:02:22',1,3,'14','cluo',3,''),(29,'2015-04-24 18:58:45',1,3,'21','kylebittinger',1,''),(30,'2015-04-24 18:58:55',1,3,'21','kylebittinger',2,'Changed is_staff.'),(31,'2015-05-14 12:24:58',1,3,'22','morganx',2,'Changed is_staff.');
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_comment_flags`
--

DROP TABLE IF EXISTS `django_comment_flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_comment_flags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `flag` varchar(30) NOT NULL,
  `flag_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`comment_id`,`flag`),
  KEY `django_comment_flags_6340c63c` (`user_id`),
  KEY `django_comment_flags_3925f323` (`comment_id`),
  KEY `django_comment_flags_9f00eb17` (`flag`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_comment_flags`
--

LOCK TABLES `django_comment_flags` WRITE;
/*!40000 ALTER TABLE `django_comment_flags` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_comment_flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_comments`
--

DROP TABLE IF EXISTS `django_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_type_id` int(11) NOT NULL,
  `object_pk` longtext NOT NULL,
  `site_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(75) NOT NULL,
  `user_url` varchar(200) NOT NULL,
  `comment` longtext NOT NULL,
  `submit_date` datetime NOT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL,
  `is_removed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_comments_37ef4eb4` (`content_type_id`),
  KEY `django_comments_99732b5c` (`site_id`),
  KEY `django_comments_6340c63c` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_comments`
--

LOCK TABLES `django_comments` WRITE;
/*!40000 ALTER TABLE `django_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'permission','auth','permission'),(2,'group','auth','group'),(3,'user','auth','user'),(4,'content type','contenttypes','contenttype'),(5,'redirect','redirects','redirect'),(6,'session','sessions','session'),(7,'site','sites','site'),(8,'Setting','conf','setting'),(9,'Site permission','core','sitepermission'),(10,'Comment','generic','threadedcomment'),(11,'Keyword','generic','keyword'),(12,'assigned keyword','generic','assignedkeyword'),(13,'Rating','generic','rating'),(14,'Form','forms','form'),(15,'Field','forms','field'),(16,'Form entry','forms','formentry'),(17,'Form field entry','forms','fieldentry'),(18,'Page','pages','page'),(19,'Rich text page','pages','richtextpage'),(20,'Link','pages','link'),(21,'Category','knowledge','category'),(22,'Question','knowledge','question'),(23,'Response','knowledge','response'),(24,'log entry','admin','logentry'),(25,'comment','comments','comment'),(26,'comment flag','comments','commentflag');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_redirect`
--

DROP TABLE IF EXISTS `django_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_redirect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `old_path` varchar(200) NOT NULL,
  `new_path` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `site_id` (`site_id`,`old_path`),
  KEY `django_redirect_99732b5c` (`site_id`),
  KEY `django_redirect_acd0874a` (`old_path`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_redirect`
--

LOCK TABLES `django_redirect` WRITE;
/*!40000 ALTER TABLE `django_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_b7b81f0c` (`expire_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('g005mnw9rsgnoc3pznzl9o6g8wd25hje','OTE4YmI1ZWVlYmNkNzMwYTliYWRlNDRlNGY3NzdkYzU5OGFkYjdlNTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-06-12 08:20:15'),('uhh31097meqcghrodyn2coptu36uoaqi','ZjVmZDYxMzU5MDU2YjQzN2VkNmI2OWMxMTg3NDQ4MTE3MDI1YzNkYzp7fQ==','2014-06-13 19:13:34'),('qtzvnt89hoamx6rbjs3frpo1bk5f9i92','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-06-13 22:07:43'),('b0ru5jr7dgczz91z9x330er1gs117ygo','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-06-13 22:15:32'),('nnkihj8vl1jjaz27hwwftj97r005jegg','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-06-13 23:37:51'),('hlsxj8vj1tzacjc44s3by3plrxd3uxki','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2014-06-13 22:28:40'),('oyxbncrmddcyjb0tzkpcf3m5ehr0uu04','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-06-27 17:42:55'),('ywl8b2qp0wdsdx0vc3gmg7e9ixld056q','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2014-06-14 00:28:15'),('coqxqcmyko3kfuk2nggybdx7urorfazl','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-07-11 19:12:10'),('yyms3igakjosbbyu5uecqcoosjz1kvan','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-07-11 20:12:18'),('wiz0cee96zy1bufm87elq0a6f47oocxg','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-07-22 15:18:11'),('flxvepq90cg5sce9lid4otj6f1koy77g','MmM2N2Y2MTBhZWE4YjY3YTQ1OTJiNzA5ZDU2YmViOWQ2M2M3ZjUxNTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjV9','2014-07-22 22:03:32'),('26b5ckcy9vf51hc2juh1jpkuytncdulg','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-07-21 19:38:15'),('21nqpr6vb98hjp86yi3t8p2ec2vlx070','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-07-23 12:23:08'),('ji0plxa358nofot4z2qxy9xmuejftrdo','MmM2N2Y2MTBhZWE4YjY3YTQ1OTJiNzA5ZDU2YmViOWQ2M2M3ZjUxNTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjV9','2014-07-23 22:11:42'),('nglyfy7xa93ewah2lw67fpb9wd0bnzav','MmM2N2Y2MTBhZWE4YjY3YTQ1OTJiNzA5ZDU2YmViOWQ2M2M3ZjUxNTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjV9','2014-07-24 02:05:11'),('25w7xbahxe1f9l5r84mi5d94wzoze9mx','MmM2N2Y2MTBhZWE4YjY3YTQ1OTJiNzA5ZDU2YmViOWQ2M2M3ZjUxNTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjV9','2014-07-24 05:38:19'),('71wlbtwbp3kw58zq1d8o2vyolbpyle0v','MmM2N2Y2MTBhZWE4YjY3YTQ1OTJiNzA5ZDU2YmViOWQ2M2M3ZjUxNTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjV9','2014-07-24 05:58:51'),('bnbmfha5bjx9lvso87wyf3u61casb9cl','MmM2N2Y2MTBhZWE4YjY3YTQ1OTJiNzA5ZDU2YmViOWQ2M2M3ZjUxNTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjV9','2014-07-24 06:12:25'),('hbbheagoanaygblazdy6ic8nqib6xtby','NDBiMjMxZWFlYzYxNGJhNDU2NWFiN2ZiYmMxOGIyZTc5NDhhMDNmYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjZ9','2014-07-24 10:45:55'),('4w09k3b4w99arzzv4ent00hzaiauxuqv','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-07-24 14:22:47'),('wkdvm38xnc8i1182zfianzkjs36udv54','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-07-31 19:25:46'),('sn5l8ksby17woigt302ssr1z5j7gecgv','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-08-06 14:30:47'),('69ueddb1xbwwn0xjrs42etqai0baih0b','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-08-19 16:28:54'),('zuprn51psds697g0qx7q9fouomg9oyhu','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-08-21 18:12:02'),('8wapesar53bjzdi7abd5z7pk9a5un4nh','ZmMwZmM1NzRlMWFlNTdmMmM2YmJkM2FlODM4OGRiZDhkNjFjMjI0Mjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjd9','2014-08-21 18:15:21'),('uve9zqw4kmwcsikenbreazfnbf5puxu9','ZmMwZmM1NzRlMWFlNTdmMmM2YmJkM2FlODM4OGRiZDhkNjFjMjI0Mjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjd9','2014-08-21 20:17:57'),('fcuxzfziddh23dkqa9pit01ysqozn9c6','ZmMwZmM1NzRlMWFlNTdmMmM2YmJkM2FlODM4OGRiZDhkNjFjMjI0Mjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjd9','2014-08-22 13:41:29'),('5yu4yp0q0133u7rj0c2dw1h536k3cj1n','ZmMwZmM1NzRlMWFlNTdmMmM2YmJkM2FlODM4OGRiZDhkNjFjMjI0Mjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjd9','2014-08-22 18:48:18'),('d31xzqq86wf4hi0wlsh7t7899ufc9q4u','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-08-25 18:00:27'),('tw5j2hy23h9fvo5tf3mz643ojju1hf75','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-09-01 16:27:03'),('plmtjun1w2hl94p3pr6ar7kdwmp0oxo7','NDBiMjMxZWFlYzYxNGJhNDU2NWFiN2ZiYmMxOGIyZTc5NDhhMDNmYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjZ9','2014-09-01 20:09:06'),('cm8un6xmd5sceu1c0d7il4hzlk3htdu8','ZTIyMTNmNTI5MzdjOTFhNTg1YmMxNjZmZDQ3YmYxNDFhMjVhMzBhODp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjh9','2014-09-17 17:13:49'),('wt6ibh01qt0seopltf5rdh1qs2ipmskm','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-09-19 19:38:33'),('lwsc8qwqzpxrzt8y6pp3ycmb5ufe82yx','NDBiMjMxZWFlYzYxNGJhNDU2NWFiN2ZiYmMxOGIyZTc5NDhhMDNmYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjZ9','2014-09-17 18:38:14'),('tkv28tl2h14fk3hovdo2m9rz817n1s7z','ZTIyMTNmNTI5MzdjOTFhNTg1YmMxNjZmZDQ3YmYxNDFhMjVhMzBhODp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjh9','2014-09-19 15:40:16'),('we4d75usthu79l8kt896yrx40jq1xofv','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2014-09-19 18:25:35'),('3ca1u2klfnpczopqo2waeop7t3gk0x9r','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2014-09-22 17:05:54'),('wufu8iuwzz2795wu1vv1vc3tuq3i1hcw','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-10-06 18:02:20'),('j2otgmfjnufpfnfbqivduflvhk8iykgp','ZTcwYTZhZDg3NGE5MDUzMGZkNzM1YzVhODgzNWYyMjIwMzJjNjJkODp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjEwfQ==','2014-10-06 18:17:46'),('edknbasx16a0uqyai7et6ijxvdxlmo26','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2014-10-06 18:49:06'),('2o7apgzbtwtphbx2mo9ve07pb95ncm1w','NGI0Y2E3ZGViOWU2Yzc0OWUxZjcyYjllZWM3NjMzNWE2MDk0YzNmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjExfQ==','2014-10-06 18:17:55'),('0ahy2xmzhwejwhjn5ojpyvtlcdgcvxe9','ZmMwZmM1NzRlMWFlNTdmMmM2YmJkM2FlODM4OGRiZDhkNjFjMjI0Mjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjd9','2014-10-06 18:20:21'),('8ws7zlfmxzejj5xskxblt1fh5qbpyjs4','NDBiMjMxZWFlYzYxNGJhNDU2NWFiN2ZiYmMxOGIyZTc5NDhhMDNmYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjZ9','2014-10-06 18:18:33'),('ptw0omejjmuslbod0gfwa3km5rub6468','ZmMwZmM1NzRlMWFlNTdmMmM2YmJkM2FlODM4OGRiZDhkNjFjMjI0Mjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjd9','2014-10-06 18:20:49'),('rci6114xlt4rq0d9iqwuewgyky3c5ml0','NDQ1MjAzNzc0NjlmNmQxM2NhOTU2ZTYzODdiMDI2Zjk4MzRhZjgyMDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjEyfQ==','2014-10-06 19:38:54'),('yufwfdvg9nxhziblbkflc35we8si108x','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-10-13 14:39:10'),('bmqmhm7lr50gzrp0i6q7b2wsdt1cvpd7','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2014-10-07 23:35:50'),('8svjmcgbbtyhiexls1l0emnsg7xo1tal','ZTIyMTNmNTI5MzdjOTFhNTg1YmMxNjZmZDQ3YmYxNDFhMjVhMzBhODp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjh9','2014-10-07 23:02:59'),('kfsaisjkf75uo71ufawlqi9qfakyd7yd','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2014-10-13 14:29:29'),('tgese55p5sigh6588dlktby824d9jnvt','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-11-17 15:08:58'),('p2plk2hyt7zwhnn2yogo2jqeqp432sqw','NDBiMjMxZWFlYzYxNGJhNDU2NWFiN2ZiYmMxOGIyZTc5NDhhMDNmYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjZ9','2014-11-17 18:12:17'),('50p7dhgaw4jzdf57fgijtb3x9qjmb9vm','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2014-11-17 17:55:43'),('j8m27pobrht2zbixwhewhpen71i1jg6f','NGI0Y2E3ZGViOWU2Yzc0OWUxZjcyYjllZWM3NjMzNWE2MDk0YzNmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjExfQ==','2014-11-17 17:07:56'),('4rkfbnkfgu5rdhuhbq38ejvlrf1b6urj','ZmMwZmM1NzRlMWFlNTdmMmM2YmJkM2FlODM4OGRiZDhkNjFjMjI0Mjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjd9','2014-11-17 17:11:40'),('uuzollad3jpfwfb1l6kddgwybv93qlop','NGI0Y2E3ZGViOWU2Yzc0OWUxZjcyYjllZWM3NjMzNWE2MDk0YzNmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjExfQ==','2014-11-17 23:18:41'),('oawfh2d5rk7x524i914iehreksux957h','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2014-11-17 18:44:48'),('ipp537jjtua2dwi75hwhb5l4mmphb8ve','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-11-28 19:13:12'),('3pqweqfiq9z03oqucf6xlursq58qferm','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2014-11-23 04:20:56'),('atn469x1t4rxv7ljgaj3q466xg88oall','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-12-05 15:41:41'),('rs7xnmcih7rjo6lpr22jk54v20vay0hb','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2014-11-28 21:15:26'),('aojzpd7bqs49qoqw3e2rp5p4u9bpmzbl','YjhhMzIyNDFlYTgyYjlmOTA1NmM3NzY3ZjQyZTAyMDMzNDgwMDAxYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjE0fQ==','2014-12-05 15:43:21'),('xz6g661rx9bclzw2z7dd27bzf4m15lha','ZmMwZmM1NzRlMWFlNTdmMmM2YmJkM2FlODM4OGRiZDhkNjFjMjI0Mjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjd9','2014-12-08 16:18:11'),('tftyomfpdifgcku8m2juil0cmoy3zogb','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2014-12-06 22:51:54'),('uek8m5ost7hsr843iva5h1pxgbuve72u','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-12-10 13:14:44'),('rn826vq075h7a4cdegqgo95ckybxf6o3','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2014-12-08 18:02:53'),('uxqcbfo1jm53217rjgbop8s3ey6238qc','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-12-08 17:35:36'),('vp7vvmbltzr6lywic3lljeb1sepq6a3h','ZmMwZmM1NzRlMWFlNTdmMmM2YmJkM2FlODM4OGRiZDhkNjFjMjI0Mjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjd9','2014-12-08 17:36:23'),('7uy7gl6869nko4fjsc37llmgobgwg2zv','NGI0Y2E3ZGViOWU2Yzc0OWUxZjcyYjllZWM3NjMzNWE2MDk0YzNmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjExfQ==','2014-12-08 17:36:26'),('ok0vw7100ctcxksabhbzkwv1iw7vp6f8','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2014-12-17 19:29:43'),('e244uqy3x27rp6zl3da1m4pqj27abwot','ZmMwZmM1NzRlMWFlNTdmMmM2YmJkM2FlODM4OGRiZDhkNjFjMjI0Mjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjd9','2014-12-18 21:06:49'),('uz6eu68qi1ik3x6vcrtihx48ra2ra6rm','ZmMwZmM1NzRlMWFlNTdmMmM2YmJkM2FlODM4OGRiZDhkNjFjMjI0Mjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjd9','2014-12-20 14:22:03'),('dlphq50zujgj5d2zutlg2x6q5gklvmvt','YzhjOWM2YmQ2MDA0NDkwNGUwYzgzMzEyMTc4MzUzZDcyYzk3ZTM1Mjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjEzfQ==','2014-12-26 22:52:28'),('tfs49xezd2zz6ezr9bhk91p1kks6je1v','ZmMwZmM1NzRlMWFlNTdmMmM2YmJkM2FlODM4OGRiZDhkNjFjMjI0Mjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjd9','2015-01-21 19:27:58'),('12uo3w8fhiygbtle14njwfbrlapk06ts','M2QyNmM1ZTdiZDRjYWNmZTMyZWMwOTM3MTE5NDFlN2QwMTZhYmMyNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjJ9','2015-02-05 15:08:14'),('onqq9h5mn2rjlwzjio07wqiysymcx238','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2015-02-05 15:21:54'),('ozr9pysuujumu0to4vyc1a7i9ru0423s','YjEyNGUyNWM1MDRiMDEwYTQ2ZTMwY2FhNDAxOTBiMmVhYTI2YzRhNDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjE1fQ==','2015-02-05 15:48:51'),('vcdb10l5fprotkip6qnf4g943tcy5579','NmI3NGIzNTg4MzQ2Mjg1YzYwZWFmYTFjMTA2MWRiNzkxNDYxYzg1Yzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjE2fQ==','2015-02-06 17:14:10'),('lmomdsbdx9s78po73s28ipqmevc06ky0','MWNiMTBiOWVjYWJjNzAzYzRlZDZkNDQ1NWExOGExZDIyOWM2YWI3Nzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjE3fQ==','2015-02-06 17:16:31'),('sv4yhz1y8unhxwn4ei2kzgder44vkv9n','NmI5OGM3NzkxNDRjM2YxM2YxMWMyNDRjN2EyYWRiYWI3MmIxYjU4NDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjE4fQ==','2015-02-06 17:23:09'),('a8hna3wpijwry6l068ftugkopz7s11dx','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2015-02-06 17:23:31'),('7bvojeuk4as0b3iu8eku88sbt1ai88ki','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2015-02-10 20:09:42'),('khoi6wdedycv81itk17nloibmhteo9su','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2015-02-08 23:48:09'),('ah2mjtqmhq7s20sx8dgymcyup2h8vtye','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2015-02-17 15:50:03'),('t0ecs2wdfdvmd1tpnr9masvhf363ppl7','NDBiMjMxZWFlYzYxNGJhNDU2NWFiN2ZiYmMxOGIyZTc5NDhhMDNmYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjZ9','2015-02-24 21:20:44'),('h96eee0dhz2l7rs24h41ckxhirm9ml12','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2015-02-18 14:47:50'),('vlanvtxgg84hs0duxjp8g3cin5qu0o4w','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2015-05-07 19:34:05'),('3bf8kqfwngehgwuoi43w97836oqq56xu','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2015-05-08 13:26:32'),('hul94vn14wihlg693194ohft5cwdsbib','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2015-05-08 18:57:33'),('facgwwa2c6wnn37vehtlkqs4t7zv2t74','NzRiNjU0MmJjZjE2OWZiMzlhM2ExNjg4YjBiZTU3ODVjMDNiNjg0Nzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjIxfQ==','2015-05-08 19:04:40'),('3t8czsaxl3lfwjrd41gcqftd5u9eamul','ZWM0NTVjNGYwNzZiZmU0NTc0MzBiYWZiZjY2ZDE1ODUzZDhlMjlmODp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjIyfQ==','2015-05-27 22:11:29'),('142ejq2xawah4ib9qbie0yppqogf0fr8','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2015-05-28 12:24:45'),('ccta2lj2e42xe645rxc7a0h027fuajoc','NzRiNjU0MmJjZjE2OWZiMzlhM2ExNjg4YjBiZTU3ODVjMDNiNjg0Nzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjIxfQ==','2015-06-10 20:24:11'),('hxtdp1nhzr3zuf6oz0u1gcu4ub6kpjmj','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2015-06-16 14:37:22'),('1bowx8syjf5bxz65ox06bxzqo3tdvpe6','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2015-11-03 13:49:58'),('ryw4gpeprfegs0b7bw0tbozg9ekls7eb','MmFmODg1ZWM4MmMyN2Q2ZThiODgxNDMzNDc1MDg1NDgzYTMyNDg1ODp7fQ==','2015-06-16 14:41:58'),('dq8blew7nxtd175az74go440cgxjy1yz','NDBiMjMxZWFlYzYxNGJhNDU2NWFiN2ZiYmMxOGIyZTc5NDhhMDNmYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjZ9','2015-11-06 09:51:10'),('9kd7egv71hf96bh9uapjj7739n9hqoh1','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2016-01-29 22:49:06'),('ue0j9ig9siv7rxadp93glpui1inddls4','NDBiMjMxZWFlYzYxNGJhNDU2NWFiN2ZiYmMxOGIyZTc5NDhhMDNmYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjZ9','2016-01-29 21:52:17'),('a58pl4gyx3vpeyoj9iz1rsu47plm40gi','MTZkZmJmMGE4NDgwZDI3ZWYwZWRiN2NlZjg3NmU2OGRjMTc1ZWViYTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nb19hdXRoX2xkYXAuYmFja2VuZC5MREFQQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9','2016-02-18 15:00:41');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_site`
--

DROP TABLE IF EXISTS `django_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_site`
--

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
INSERT INTO `django_site` VALUES (1,'127.0.0.1:8000','Default');
/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_field`
--

DROP TABLE IF EXISTS `forms_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `_order` int(11) DEFAULT NULL,
  `form_id` int(11) NOT NULL,
  `label` varchar(200) NOT NULL,
  `field_type` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `choices` varchar(1000) NOT NULL,
  `default` varchar(2000) NOT NULL,
  `placeholder_text` varchar(100) NOT NULL,
  `help_text` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `forms_field_c3d79a6c` (`form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_field`
--

LOCK TABLES `forms_field` WRITE;
/*!40000 ALTER TABLE `forms_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_fieldentry`
--

DROP TABLE IF EXISTS `forms_fieldentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_fieldentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `value` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `forms_fieldentry_e8d920b6` (`entry_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_fieldentry`
--

LOCK TABLES `forms_fieldentry` WRITE;
/*!40000 ALTER TABLE `forms_fieldentry` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_fieldentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_form`
--

DROP TABLE IF EXISTS `forms_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_form` (
  `page_ptr_id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `button_text` varchar(50) NOT NULL,
  `response` longtext NOT NULL,
  `send_email` tinyint(1) NOT NULL,
  `email_from` varchar(75) NOT NULL,
  `email_copies` varchar(200) NOT NULL,
  `email_subject` varchar(200) NOT NULL,
  `email_message` longtext NOT NULL,
  PRIMARY KEY (`page_ptr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_form`
--

LOCK TABLES `forms_form` WRITE;
/*!40000 ALTER TABLE `forms_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_formentry`
--

DROP TABLE IF EXISTS `forms_formentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_formentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_id` int(11) NOT NULL,
  `entry_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `forms_formentry_c3d79a6c` (`form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_formentry`
--

LOCK TABLES `forms_formentry` WRITE;
/*!40000 ALTER TABLE `forms_formentry` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_formentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_assignedkeyword`
--

DROP TABLE IF EXISTS `generic_assignedkeyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_assignedkeyword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `_order` int(11) DEFAULT NULL,
  `keyword_id` int(11) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `object_pk` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `generic_assignedkeyword_0e202173` (`keyword_id`),
  KEY `generic_assignedkeyword_37ef4eb4` (`content_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_assignedkeyword`
--

LOCK TABLES `generic_assignedkeyword` WRITE;
/*!40000 ALTER TABLE `generic_assignedkeyword` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_assignedkeyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_keyword`
--

DROP TABLE IF EXISTS `generic_keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_keyword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `generic_keyword_99732b5c` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_keyword`
--

LOCK TABLES `generic_keyword` WRITE;
/*!40000 ALTER TABLE `generic_keyword` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_keyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_rating`
--

DROP TABLE IF EXISTS `generic_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` int(11) NOT NULL,
  `rating_date` datetime DEFAULT NULL,
  `content_type_id` int(11) NOT NULL,
  `object_pk` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `generic_rating_37ef4eb4` (`content_type_id`),
  KEY `generic_rating_6340c63c` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_rating`
--

LOCK TABLES `generic_rating` WRITE;
/*!40000 ALTER TABLE `generic_rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_threadedcomment`
--

DROP TABLE IF EXISTS `generic_threadedcomment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_threadedcomment` (
  `comment_ptr_id` int(11) NOT NULL,
  `rating_count` int(11) NOT NULL,
  `rating_sum` int(11) NOT NULL,
  `rating_average` double NOT NULL,
  `by_author` tinyint(1) NOT NULL,
  `replied_to_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`comment_ptr_id`),
  KEY `generic_threadedcomment_148afc3c` (`replied_to_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_threadedcomment`
--

LOCK TABLES `generic_threadedcomment` WRITE;
/*!40000 ALTER TABLE `generic_threadedcomment` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_threadedcomment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_category`
--

DROP TABLE IF EXISTS `knowledge_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knowledge_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `added` datetime NOT NULL,
  `lastchanged` datetime NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_category`
--

LOCK TABLES `knowledge_category` WRITE;
/*!40000 ALTER TABLE `knowledge_category` DISABLE KEYS */;
INSERT INTO `knowledge_category` VALUES (1,'2014-05-28 17:54:37','2014-05-28 17:54:37','Site improvements','site-improvements'),(2,'2014-05-28 17:54:56','2014-05-28 17:54:56','Workflow suggestions','workflow-suggestions'),(3,'2014-05-28 17:55:02','2014-05-28 17:55:02','Special analyses','special-analyses');
/*!40000 ALTER TABLE `knowledge_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_question`
--

DROP TABLE IF EXISTS `knowledge_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knowledge_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `added` datetime NOT NULL,
  `lastchanged` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `alert` tinyint(1) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `email` varchar(75) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `body` longtext,
  `status` varchar(32) NOT NULL,
  `locked` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `knowledge_question_6340c63c` (`user_id`),
  KEY `knowledge_question_48fb58bb` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_question`
--

LOCK TABLES `knowledge_question` WRITE;
/*!40000 ALTER TABLE `knowledge_question` DISABLE KEYS */;
INSERT INTO `knowledge_question` VALUES (1,'2015-10-23 09:55:22','2015-10-23 09:55:22',6,0,NULL,NULL,'Associate SNPs with microbial variation','I\'d like to perform a statistical analysis in which we identify microbial abundances that are significantly differential with respect to IBD risk variant alleles. I\'m worried about power, though - we have full 16S data measuring hundreds of bugs, along with hundreds of variants of interest. Help?','private',0);
/*!40000 ALTER TABLE `knowledge_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_question_categories`
--

DROP TABLE IF EXISTS `knowledge_question_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knowledge_question_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `question_id` (`question_id`,`category_id`),
  KEY `knowledge_question_categories_25110688` (`question_id`),
  KEY `knowledge_question_categories_6f33f001` (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_question_categories`
--

LOCK TABLES `knowledge_question_categories` WRITE;
/*!40000 ALTER TABLE `knowledge_question_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_question_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_response`
--

DROP TABLE IF EXISTS `knowledge_response`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knowledge_response` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `added` datetime NOT NULL,
  `lastchanged` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `alert` tinyint(1) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `email` varchar(75) DEFAULT NULL,
  `question_id` int(11) NOT NULL,
  `body` longtext,
  `status` varchar(32) NOT NULL,
  `accepted` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `knowledge_response_6340c63c` (`user_id`),
  KEY `knowledge_response_25110688` (`question_id`),
  KEY `knowledge_response_48fb58bb` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_response`
--

LOCK TABLES `knowledge_response` WRITE;
/*!40000 ALTER TABLE `knowledge_response` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_response` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_link`
--

DROP TABLE IF EXISTS `pages_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_link` (
  `page_ptr_id` int(11) NOT NULL,
  PRIMARY KEY (`page_ptr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_link`
--

LOCK TABLES `pages_link` WRITE;
/*!40000 ALTER TABLE `pages_link` DISABLE KEYS */;
INSERT INTO `pages_link` VALUES (2),(3),(4),(6),(7);
/*!40000 ALTER TABLE `pages_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_page`
--

DROP TABLE IF EXISTS `pages_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keywords_string` varchar(500) NOT NULL,
  `site_id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `_meta_title` varchar(500) DEFAULT NULL,
  `description` longtext NOT NULL,
  `gen_description` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `short_url` varchar(200) DEFAULT NULL,
  `in_sitemap` tinyint(1) NOT NULL,
  `_order` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `in_menus` varchar(100) DEFAULT NULL,
  `titles` varchar(1000) DEFAULT NULL,
  `content_model` varchar(50) DEFAULT NULL,
  `login_required` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pages_page_99732b5c` (`site_id`),
  KEY `pages_page_410d0aac` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_page`
--

LOCK TABLES `pages_page` WRITE;
/*!40000 ALTER TABLE `pages_page` DISABLE KEYS */;
INSERT INTO `pages_page` VALUES (1,'',1,'Tools','tools','','Metadata Generator',1,'2014-05-24 21:28:12','2014-05-30 13:02:27',2,'2014-05-24 21:28:11',NULL,NULL,1,0,NULL,'1,2,3','Tools','richtextpage',0),(2,'',1,'Metadata Generator','/metadata',NULL,'Tools / Metadata Generator',1,'2014-05-24 21:29:49','2014-05-24 21:29:49',2,'2014-05-24 21:29:49',NULL,NULL,0,0,1,'1,2,3','Tools / Metadata Generator','link',0),(3,'',1,'Sample-level Metadata Editor','/samplemeta',NULL,'Tools / Sample-level Metadata Editor',1,'2014-05-24 21:30:23','2014-05-24 21:30:23',2,'2014-05-24 21:30:23',NULL,NULL,0,1,1,'1,2,3','Tools / Sample-level Metadata Editor','link',0),(4,'',1,'Metatadata Validator','/validator',NULL,'Tools / Metatadata Validator',1,'2014-05-24 21:30:42','2014-05-24 21:30:42',2,'2014-05-24 21:30:42',NULL,NULL,0,2,1,'1,2,3','Tools / Metatadata Validator','link',0),(6,'',1,'Files','/files',NULL,'Tools / Files',1,'2014-05-28 17:33:23','2014-05-28 17:33:23',2,'2014-05-28 17:33:23',NULL,NULL,0,3,1,'1,2,3','Tools / Files','link',0),(7,'',1,'Support Tickets','/tickets',NULL,'Support Tickets',1,'2014-05-30 13:03:02','2014-05-30 13:03:02',2,'2014-05-30 13:03:02',NULL,NULL,0,1,NULL,'1,2,3','Support Tickets','link',0),(8,'',1,'Documents','documents','','\n\n\n Data Upload.pdf\nProcedures for uploading content to the Bioinformatics Center site. This includes methods for using the Web UI and for Secure FTP.  Italso covers the types of files that are required for processing (either manual or automated).\n\n\n\n',1,'2014-05-30 14:48:54','2014-05-30 14:48:54',2,'2014-05-30 14:48:54',NULL,NULL,1,2,NULL,'1,2,3','Documents','richtextpage',0);
/*!40000 ALTER TABLE `pages_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_richtextpage`
--

DROP TABLE IF EXISTS `pages_richtextpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_richtextpage` (
  `page_ptr_id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY (`page_ptr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_richtextpage`
--

LOCK TABLES `pages_richtextpage` WRITE;
/*!40000 ALTER TABLE `pages_richtextpage` DISABLE KEYS */;
INSERT INTO `pages_richtextpage` VALUES (8,'<table cellpadding=\"1\" border=\"1\" cellspacing=\"1\">\n<tbody>\n<tr>\n<td width=\"30%\"><a href=\"/static/media/uploads/DataUploadSOP.pdf\"><img src=\"https://ccfa.rc.fas.harvard.edu/misc/pdf-icon.png\"> Data Upload.pdf</a></td>\n<td width=\"70%\">Procedures for uploading content to the Bioinformatics Center site. This includes methods for using the Web UI and for Secure FTP.  It<br>also covers the types of files that are required for processing (either manual or automated).</td>\n</tr>\n</tbody>\n</table>\n<p></p>\n<p></p>\n<table cellpadding=\"1\" border=\"1\" cellspacing=\"1\">\n<tbody>\n<tr>\n<td><a href=\"/static/media/uploads/Metadata.pdf\"><img src=\"https://ccfa.rc.fas.harvard.edu/misc/pdf-icon.png\">Metadata.pdf</a></td>\n<td>Procedures for creation of a study-wide metadata.txt file. This file describes all of the files uploaded to the Bioinformatics Site and helps with manual and automated processing of the data. It identifies a Metadata generation form that can be used to help with this process.</td>\n</tr>\n</tbody>\n</table>\n<p></p>\n<p></p>\n<table cellpadding=\"1\" border=\"1\" cellspacing=\"1\">\n<tbody>\n<tr>\n<td><a href=\"/static/media/uploads/Map_txt.pdf\"><img src=\"https://ccfa.rc.fas.harvard.edu/misc/pdf-icon.png\">Map.txt.pdf</a></td>\n<td>Procedures for creation of a per-sample map.txt file.  This file describes the sample data uploaded to the Bioinformatics Site and helps with manual and automated processing of the data. Specifically, it describes the required fields and specifies the formats needed to help with this process.</td>\n</tr>\n</tbody>\n</table>'),(1,'<p><a href=\"/metadata\">Metadata Generator</a></p>\n<p><a href=\"/samplemeta\">Sample-level Metadata Editor</a></p>\n<p><a href=\"/validator\">Metadata Validator</a></p>\n<p><a href=\"/files\">Browse Files</a></p>');
/*!40000 ALTER TABLE `pages_richtextpage` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-05-13  8:58:05
